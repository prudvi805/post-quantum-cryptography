/* Sample service code for the QFF 2026 PS-P2 optional scanner path (planted crypto usages). */
#include <openssl/ssl.h>
#include <openssl/evp.h>

int configure(SSL_CTX *ctx) {
    SSL_CTX_set_cipher_list(ctx, "ECDHE-RSA-AES256-GCM-SHA384");   /* TLS 1.2 suite */
    SSL_CTX_set1_groups_list(ctx, "X25519MLKEM768:X25519");         /* hybrid group preferred */
    return 1;
}

EVP_PKEY *gen_dh(void) {
    return EVP_PKEY_Q_keygen(NULL, NULL, "DH", "ffdhe2048");          /* finite-field DH */
}
