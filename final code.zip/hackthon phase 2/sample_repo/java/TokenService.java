// Sample service code for the QFF 2026 PS-P2 optional scanner path (planted crypto usages).
import java.security.*;
import javax.crypto.*;

public class TokenService {
    KeyPair rsaKeys() throws Exception {
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");   // RSA-3072 JWT RS256 signing
        g.initialize(3072);
        return g.generateKeyPair();
    }
    byte[] sign(PrivateKey k, byte[] m) throws Exception {
        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(k); s.update(m); return s.sign();
    }
    Cipher legacyCipher() throws Exception {
        return Cipher.getInstance("DESede/CBC/PKCS5Padding");        // 3DES legacy
    }
    MessageDigest fingerprint() throws Exception {
        return MessageDigest.getInstance("SHA-1");                    // SHA-1 fingerprint
    }
}
