# Sample service code for the QFF 2026 PS-P2 optional scanner path (planted crypto usages).
import hashlib
from cryptography.hazmat.primitives.asymmetric import rsa, ec, padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def make_signing_key():
    return ec.generate_private_key(ec.SECP256R1())          # ECDSA P-256 request signing


def make_wrapping_key():
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)   # RSA-OAEP key wrapping


def wrap(pub, secret):
    return pub.encrypt(secret, padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None))


def encrypt_record(key, nonce, data):
    return AESGCM(key).encrypt(nonce, data, None)            # AES-256-GCM at rest


def legacy_checksum(data):
    return hashlib.md5(data).hexdigest()                     # MD5 checksum (legacy)


def integrity(data):
    return hashlib.sha256(data).hexdigest()                  # SHA-256 integrity
