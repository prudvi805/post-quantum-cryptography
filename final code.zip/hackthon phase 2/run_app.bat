@echo off
title Q-Safe Enterprise Web App (PS-P2)
echo ========================================================
echo  Launching Q-Safe Web Application (Frontend + Backend)
echo ========================================================
echo.
python start_app.py
pause
