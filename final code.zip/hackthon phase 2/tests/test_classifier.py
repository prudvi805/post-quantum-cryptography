"""Automated Unit Tests for Cryptographic Classifier (QFF 2026 PS-P2).

Verifies 100% adherence to SCHEMA.md labeling rules, rule precedence,
contradiction handling, and alias mapping.
"""
import unittest
from src.classifier import classify_record, LABELS


class TestClassifier(unittest.TestCase):
    def test_unknown_empty_and_unidentifiable(self):
        """Rule 1: UNKNOWN for blank, proprietary, or unidentifiable algorithms."""
        self.assertEqual(classify_record({"algorithm": ""}), "UNKNOWN")
        self.assertEqual(classify_record({"algorithm": "vendor default"}), "UNKNOWN")
        self.assertEqual(classify_record({"algorithm": "vendor-managed"}), "UNKNOWN")
        self.assertEqual(classify_record({"algorithm": "proprietary"}), "UNKNOWN")
        self.assertEqual(classify_record({"algorithm": "custom XOR scheme"}), "UNKNOWN")

    def test_contradiction_hash_or_symmetric_as_public_key(self):
        """Rule 1: SHA-256 or AES declared as digital_signature / key_establishment must be UNKNOWN."""
        self.assertEqual(
            classify_record({"algorithm": "SHA256", "primitive": "digital_signature"}),
            "UNKNOWN",
        )
        self.assertEqual(
            classify_record({"algorithm": "SHA-256", "primitive": "digital_signature"}),
            "UNKNOWN",
        )
        self.assertEqual(
            classify_record({"algorithm": "AES-256", "primitive": "digital_signature"}),
            "UNKNOWN",
        )
        self.assertEqual(
            classify_record({"algorithm": "AES-128", "primitive": "key_establishment"}),
            "UNKNOWN",
        )

    def test_contradiction_public_key_as_symmetric_or_hash(self):
        """Rule 1: Public-key declared as hash / symmetric_encryption must be UNKNOWN."""
        self.assertEqual(
            classify_record({"algorithm": "RSA", "primitive": "hash"}),
            "UNKNOWN",
        )
        self.assertEqual(
            classify_record({"algorithm": "ECDSA", "primitive": "symmetric_encryption"}),
            "UNKNOWN",
        )

    def test_contradiction_impossible_parameter_sets(self):
        """Rule 1: Impossible parameter sets must be UNKNOWN."""
        self.assertEqual(
            classify_record({"algorithm": "ML-KEM", "key_size_or_parameter_set": "4096"}),
            "UNKNOWN",
        )
        self.assertEqual(
            classify_record({"algorithm": "ML-KEM", "key_size_or_parameter_set": "2048"}),
            "UNKNOWN",
        )
        self.assertEqual(
            classify_record({"algorithm": "AES", "key_size_or_parameter_set": "2048"}),
            "UNKNOWN",
        )
        self.assertEqual(
            classify_record({"algorithm": "ML-DSA-65", "key_size_or_parameter_set": "ML-KEM-768"}),
            "UNKNOWN",
        )

    def test_hybrid_classification(self):
        """Rule 2: Classical + PQC combined mechanisms must be HYBRID."""
        self.assertEqual(classify_record({"algorithm": "X25519MLKEM768"}), "HYBRID")
        self.assertEqual(classify_record({"algorithm": "X25519+ML-KEM-768"}), "HYBRID")
        self.assertEqual(classify_record({"algorithm": "SecP256r1MLKEM768"}), "HYBRID")
        self.assertEqual(classify_record({"algorithm": "ECDSA-P256+ML-DSA-44"}), "HYBRID")
        self.assertEqual(classify_record({"algorithm": "mlkem768x25519-sha256"}), "HYBRID")

    def test_quantum_vulnerable_classification(self):
        """Rule 3: Classical public-key algorithms at any key size must be QUANTUM_VULNERABLE."""
        self.assertEqual(classify_record({"algorithm": "RSA", "key_size_or_parameter_set": "4096"}), "QUANTUM_VULNERABLE")
        self.assertEqual(classify_record({"algorithm": "RSA", "key_size_or_parameter_set": "1024"}), "QUANTUM_VULNERABLE")
        self.assertEqual(classify_record({"algorithm": "SHA256withRSA"}), "QUANTUM_VULNERABLE")
        self.assertEqual(classify_record({"algorithm": "ECDSA"}), "QUANTUM_VULNERABLE")
        self.assertEqual(classify_record({"algorithm": "ECDSAP256SHA256"}), "QUANTUM_VULNERABLE")
        self.assertEqual(classify_record({"algorithm": "ES256"}), "QUANTUM_VULNERABLE")
        self.assertEqual(classify_record({"algorithm": "X25519"}), "QUANTUM_VULNERABLE")
        self.assertEqual(classify_record({"algorithm": "Ed25519"}), "QUANTUM_VULNERABLE")
        self.assertEqual(classify_record({"algorithm": "DH group 14"}), "QUANTUM_VULNERABLE")
        self.assertEqual(classify_record({"algorithm": "FFDHE2048"}), "QUANTUM_VULNERABLE")
        self.assertEqual(classify_record({"algorithm": "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"}), "QUANTUM_VULNERABLE")

    def test_quantum_resistant_classification(self):
        """Rule 4: PQC mechanisms only must be QUANTUM_RESISTANT."""
        self.assertEqual(classify_record({"algorithm": "ML-KEM", "key_size_or_parameter_set": "768"}), "QUANTUM_RESISTANT")
        self.assertEqual(classify_record({"algorithm": "ML-DSA", "key_size_or_parameter_set": "ML-DSA-65"}), "QUANTUM_RESISTANT")
        self.assertEqual(classify_record({"algorithm": "SLH-DSA"}), "QUANTUM_RESISTANT")
        self.assertEqual(classify_record({"algorithm": "Kyber768"}), "QUANTUM_RESISTANT")
        self.assertEqual(classify_record({"algorithm": "XMSS"}), "QUANTUM_RESISTANT")
        self.assertEqual(classify_record({"algorithm": "LMS"}), "QUANTUM_RESISTANT")

    def test_legacy_broken_classification(self):
        """Rule 5: Classically broken symmetric/hash must be LEGACY_BROKEN."""
        self.assertEqual(classify_record({"algorithm": "MD5"}), "LEGACY_BROKEN")
        self.assertEqual(classify_record({"algorithm": "SHA-1"}), "LEGACY_BROKEN")
        self.assertEqual(classify_record({"algorithm": "SHA1"}), "LEGACY_BROKEN")
        self.assertEqual(classify_record({"algorithm": "3DES"}), "LEGACY_BROKEN")
        self.assertEqual(classify_record({"algorithm": "RC4"}), "LEGACY_BROKEN")

    def test_symmetric_or_hash_classification(self):
        """Rule 6: Adequate symmetric/hash must be SYMMETRIC_OR_HASH."""
        self.assertEqual(classify_record({"algorithm": "AES-256-GCM"}), "SYMMETRIC_OR_HASH")
        self.assertEqual(classify_record({"algorithm": "AES-128-GCM"}), "SYMMETRIC_OR_HASH")
        self.assertEqual(classify_record({"algorithm": "ChaCha20-Poly1305"}), "SYMMETRIC_OR_HASH")
        self.assertEqual(classify_record({"algorithm": "SHA-256", "primitive": "hash"}), "SYMMETRIC_OR_HASH")
        self.assertEqual(classify_record({"algorithm": "SHA3-256", "primitive": "hash"}), "SYMMETRIC_OR_HASH")
        self.assertEqual(classify_record({"algorithm": "HKDF-SHA256"}), "SYMMETRIC_OR_HASH")
        self.assertEqual(classify_record({"algorithm": "PBKDF2-HMAC-SHA256"}), "SYMMETRIC_OR_HASH")
        self.assertEqual(classify_record({"algorithm": "Argon2id"}), "SYMMETRIC_OR_HASH")


if __name__ == "__main__":
    unittest.main()
