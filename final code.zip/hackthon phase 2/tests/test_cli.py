"""Automated CLI and Contract Tests for run_inventory.py (QFF 2026 PS-P2).

Verifies command-line execution, output schema, and offline functionality.
"""
import csv
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


class TestCLI(unittest.TestCase):
    def test_run_inventory_cli(self):
        """Tests that run_inventory.py runs via CLI and produces all required columns."""
        input_csv = ROOT / "inventory_dev.csv"
        output_csv = ROOT / "results" / "test_cli_output.csv"

        cmd = [
            sys.executable,
            str(ROOT / "run_inventory.py"),
            "--input",
            str(input_csv),
            "--output",
            str(output_csv),
        ]
        res = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(res.returncode, 0, f"CLI error: {res.stderr}")
        self.assertTrue(output_csv.exists())

        required_cols = [
            "asset_id",
            "predicted_label",
            "priority_score",
            "priority_rank",
            "recommended_action",
            "migration_wave",
            "depends_on",
            "rationale",
        ]

        with open(output_csv, mode="r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            self.assertEqual(reader.fieldnames, required_cols)
            rows = list(reader)
            self.assertEqual(len(rows), 150)

            # Check that every record has valid non-empty fields
            for r in rows:
                self.assertTrue(r["asset_id"])
                self.assertIn(
                    r["predicted_label"],
                    [
                        "QUANTUM_VULNERABLE",
                        "QUANTUM_RESISTANT",
                        "HYBRID",
                        "SYMMETRIC_OR_HASH",
                        "LEGACY_BROKEN",
                        "UNKNOWN",
                    ],
                )
                score = float(r["priority_score"])
                self.assertTrue(0 <= score <= 100)
                self.assertIn(r["migration_wave"], ["1", "2", "3", "review"])
                self.assertTrue(r["rationale"])


if __name__ == "__main__":
    unittest.main()
