"""Automated Tests for Prioritization and Risk Scoring Logic (QFF 2026 PS-P2).

Verifies 0-100 score bounds, wave assignment, review priority for UNKNOWN,
and differentiation of assets with varying business context.
"""
import unittest
from src.prioritizer import (
    calculate_risk_score,
    determine_recommendation_and_wave,
    prioritize_inventory,
)


class TestPrioritization(unittest.TestCase):
    def test_score_bounds(self):
        """Risk scores must always stay strictly within [0, 100]."""
        r_high = {
            "criticality": "critical",
            "internet_exposed": "yes",
            "data_sensitivity": "restricted",
            "data_retention_years": "25",
            "environment": "prod",
            "key_size_or_parameter_set": "1024",
        }
        score_high, _ = calculate_risk_score(r_high, "QUANTUM_VULNERABLE")
        self.assertLessEqual(score_high, 100)
        self.assertGreaterEqual(score_high, 0)

        r_low = {
            "criticality": "low",
            "internet_exposed": "no",
            "data_sensitivity": "public",
            "data_retention_years": "0",
            "environment": "dev",
        }
        score_low, _ = calculate_risk_score(r_low, "QUANTUM_RESISTANT")
        self.assertGreaterEqual(score_low, 0)
        self.assertLessEqual(score_low, 100)

    def test_unknown_receives_review_priority_not_zero(self):
        """Acceptance condition: UNKNOWN records must receive a review priority, never 0."""
        r_unknown = {
            "algorithm": "",
            "criticality": "medium",
            "internet_exposed": "yes",
        }
        score, rationale = calculate_risk_score(r_unknown, "UNKNOWN")
        self.assertGreater(score, 0)
        self.assertIn("label=UNKNOWN", rationale)

        action, wave = determine_recommendation_and_wave(r_unknown, "UNKNOWN", score)
        self.assertEqual(wave, "review")
        self.assertIn("Manual review", action)

    def test_three_assets_receive_different_priorities(self):
        """Objective 4: Show why at least three assets receive different migration priorities."""
        asset_1 = {
            "asset_id": "TEST-01",
            "algorithm": "RSA",
            "key_size_or_parameter_set": "1024",
            "internet_exposed": "yes",
            "criticality": "critical",
            "data_sensitivity": "restricted",
            "data_retention_years": "20",
            "environment": "prod",
        }
        asset_2 = {
            "asset_id": "TEST-02",
            "algorithm": "ECDSA",
            "key_size_or_parameter_set": "256",
            "internet_exposed": "no",
            "criticality": "low",
            "data_sensitivity": "internal",
            "data_retention_years": "1",
            "environment": "dev",
        }
        asset_3 = {
            "asset_id": "TEST-03",
            "algorithm": "AES-256-GCM",
            "internet_exposed": "no",
            "criticality": "low",
            "data_sensitivity": "public",
            "data_retention_years": "0",
            "environment": "dev",
        }

        preds = prioritize_inventory(
            [asset_1, asset_2, asset_3],
            ["QUANTUM_VULNERABLE", "QUANTUM_VULNERABLE", "SYMMETRIC_OR_HASH"],
        )
        scores = [p["priority_score"] for p in preds]

        # All 3 scores must be strictly distinct
        self.assertEqual(len(set(scores)), 3)
        self.assertGreater(scores[0], scores[1])
        self.assertGreater(scores[1], scores[2])
        self.assertEqual(preds[0]["priority_rank"], 1)
        self.assertEqual(preds[0]["migration_wave"], "1")
        self.assertEqual(preds[2]["migration_wave"], "3")


if __name__ == "__main__":
    unittest.main()
