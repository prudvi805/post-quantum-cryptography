"""PS-P2 core package."""
