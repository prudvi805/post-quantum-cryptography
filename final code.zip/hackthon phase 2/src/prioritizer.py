"""Prioritization and Migration Planning Engine for QFF 2026 Phase 2 (PS-P2).

Computes a transparent 0-100 risk score, ranks records, assigns migration waves,
infers dependencies, and produces actionable recommendations and explainable rationales.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple


def calculate_risk_score(record: Dict[str, Any], label: str) -> Tuple[int, str]:
    """Calculates a transparent 0-100 risk priority score and rationale.

    Components:
    - Base risk from cryptographic category (Shor vulnerability, classical break, ambiguity)
    - Business criticality (critical, high, medium, low)
    - Internet exposure (yes, no, missing)
    - Data sensitivity (restricted, confidential, internal, public)
    - Data retention years (Mosca's Theorem: long retention needs earlier migration)
    - Deployment environment (prod, staging, dev)
    """
    rationale_parts = [f"label={label}"]
    score = 0.0

    # 1. Base Score by Cryptographic Label
    if label == "QUANTUM_VULNERABLE":
        score += 50.0
        # Check for weak classical parameters (e.g. RSA-1024) which are broken classically
        param = str(record.get("key_size_or_parameter_set") or "")
        alg = str(record.get("algorithm") or "").upper()
        if "1024" in param or "1024" in alg:
            score += 15.0
            rationale_parts.append("weak_classical_key(<2048b)")
    elif label == "LEGACY_BROKEN":
        # Classically vulnerable today
        score += 45.0
    elif label == "UNKNOWN":
        # Ambiguous / unverified crypto requires review priority, never 0
        score += 40.0
    elif label == "HYBRID":
        # Protected against harvest-now-decrypt-later, but eventually needs pure PQC
        score += 18.0
    elif label == "SYMMETRIC_OR_HASH":
        score += 10.0
    elif label == "QUANTUM_RESISTANT":
        score += 5.0
        alg = str(record.get("algorithm") or "").upper()
        if "KYBER" in alg or "DILITHIUM" in alg:
            score += 5.0
            rationale_parts.append("pre_standard_PQC")

    # 2. Criticality (0 to 15 points)
    crit = (record.get("criticality") or "").strip().lower()
    if crit == "critical":
        score += 15.0
        rationale_parts.append("criticality=critical")
    elif crit == "high":
        score += 10.0
        rationale_parts.append("criticality=high")
    elif crit == "medium":
        score += 5.0
        rationale_parts.append("criticality=medium")
    elif crit == "low":
        score += 0.0
        rationale_parts.append("criticality=low")
    else:
        # Missing criticality is never assumed low (SCHEMA.md §1)
        score += 8.0
        rationale_parts.append("criticality=unspecified")

    # 3. Internet Exposure (0 to 15 points)
    exposed = (record.get("internet_exposed") or "").strip().lower()
    if exposed == "yes":
        score += 15.0
        rationale_parts.append("internet_exposed=yes")
    elif exposed == "no":
        score += 0.0
        rationale_parts.append("internet_exposed=no")
    else:
        score += 10.0
        rationale_parts.append("internet_exposed=unspecified")

    # 4. Data Sensitivity (0 to 10 points)
    sens = (record.get("data_sensitivity") or "").strip().lower()
    if sens == "restricted":
        score += 10.0
        rationale_parts.append("sensitivity=restricted")
    elif sens == "confidential":
        score += 7.0
        rationale_parts.append("sensitivity=confidential")
    elif sens == "internal":
        score += 4.0
        rationale_parts.append("sensitivity=internal")
    elif sens == "public":
        score += 0.0
        rationale_parts.append("sensitivity=public")
    else:
        score += 5.0
        rationale_parts.append("sensitivity=unspecified")

    # 5. Data Retention Years (Mosca's Theorem: 0 to 10 points)
    ret_str = str(record.get("data_retention_years") or "").strip()
    try:
        ret_val = int(float(ret_str)) if ret_str else None
    except ValueError:
        ret_val = None

    if ret_val is not None:
        if ret_val >= 15:
            score += 10.0
            rationale_parts.append(f"retention={ret_val}y(high)")
        elif ret_val >= 10:
            score += 7.0
            rationale_parts.append(f"retention={ret_val}y(med)")
        elif ret_val >= 5:
            score += 4.0
            rationale_parts.append(f"retention={ret_val}y")
        elif ret_val > 0:
            score += 2.0
            rationale_parts.append(f"retention={ret_val}y")
        else:
            rationale_parts.append("retention=0y")
    else:
        score += 3.0
        rationale_parts.append("retention=unspecified")

    # 6. Environment (0 to 5 points)
    env = (record.get("environment") or "").strip().lower()
    if env == "prod":
        score += 5.0
        rationale_parts.append("env=prod")
    elif env == "staging":
        score += 2.0
        rationale_parts.append("env=staging")
    elif env == "dev":
        score += 0.0
        rationale_parts.append("env=dev")
    else:
        score += 2.0

    final_score = int(round(min(100.0, max(0.0, score))))
    rationale = "; ".join(rationale_parts)
    return final_score, rationale


def determine_recommendation_and_wave(
    record: Dict[str, Any], label: str, score: int
) -> Tuple[str, str]:
    """Generates an actionable migration recommendation and assigns a migration wave.

    Waves:
    - 'review': All UNKNOWN entries requiring human security review
    - '1': High priority / immediate (score >= 70, exposed QV, classically broken in prod)
    - '2': Medium priority (score 45 - 69, internal QV, hybrid transitions)
    - '3': Low priority (score < 45, adequate symmetric/hash, PQC maintenance)
    """
    alg = (record.get("algorithm") or "").strip()
    alg_upper = alg.upper()
    prim = (record.get("primitive") or "").strip().lower()
    asset_type = (record.get("asset_type") or "").strip().lower()
    param = str(record.get("key_size_or_parameter_set") or "")

    if label == "UNKNOWN":
        wave = "review"
        notes = (record.get("notes") or "").strip()
        if not alg:
            action = "Manual review: algorithm not recorded in asset metadata; inspect host/code"
        elif "inconsistent" in notes or "contradict" in notes or "4096" in param or "2048" in param:
            action = f"Manual review: contradiction detected in {alg} with parameter {param}; clarify cryptographic role"
        elif "signature scheme not specified" in notes or "SHA" in alg_upper:
            action = f"Manual review: incomplete signature specification ({alg}); verify whether ML-DSA-65 applies"
        else:
            action = f"Manual review: unidentifiable or proprietary algorithm '{alg}'; verify standard compliance"

    elif label == "QUANTUM_VULNERABLE":
        wave = "1" if score >= 70 else "2"
        if "1024" in param or "1024" in alg:
            action = f"URGENT: Deprecate {alg} (1024-bit key classically insecure); migrate directly to ML-DSA-65 (FIPS 204)"
        elif prim == "key_establishment" or any(k in alg_upper for k in ["DH", "ECDH", "ECDHE", "X25519"]):
            action = f"Migrate key exchange from {alg} to ML-KEM-768 (FIPS 203) or hybrid X25519+ML-KEM-768"
        elif prim in ("digital_signature", "public_key_encryption") or any(s in alg_upper for s in ["RSA", "ECDSA", "ED25519"]):
            if asset_type == "certificate":
                action = f"Replace {alg} certificate with ML-DSA-65 (FIPS 204) or hybrid X.509 certificate"
            else:
                action = f"Migrate signing/encryption from {alg} to ML-DSA-65 (FIPS 204)"
        else:
            action = f"Migrate classical public-key mechanism {alg} to NIST PQC (FIPS 203 ML-KEM / FIPS 204 ML-DSA)"

    elif label == "LEGACY_BROKEN":
        wave = "1" if score >= 60 else "2"
        if any(h in alg_upper for h in ["MD5", "SHA-1", "SHA1"]):
            action = f"Replace deprecated hash {alg} with SHA-256 (FIPS 180-4) or SHA3-256 (FIPS 202); use Argon2id for passwords"
        elif any(c in alg_upper for c in ["3DES", "DES", "RC4", "TDEA"]):
            action = f"Replace deprecated cipher {alg} with AES-256-GCM (FIPS 197)"
        else:
            action = f"Deprecate legacy mechanism {alg}; upgrade to modern FIPS standard"

    elif label == "HYBRID":
        wave = "2" if score >= 50 else "3"
        action = f"Maintain hybrid scheme {alg}; plan eventual transition to pure ML-KEM-768 / ML-DSA-65 as clients upgrade"

    elif label == "QUANTUM_RESISTANT":
        wave = "3"
        if "KYBER" in alg_upper or "DILITHIUM" in alg_upper or "SPHINCS" in alg_upper:
            action = f"Upgrade pre-standard PQC ({alg}) to official NIST FIPS 203 (ML-KEM) / FIPS 204 (ML-DSA)"
        else:
            action = f"Standard compliant PQC ({alg}); retain and monitor for library updates"

    else:  # SYMMETRIC_OR_HASH
        wave = "3"
        if "128" in alg_upper or "128" in param:
            action = f"Maintain {alg}; evaluate migration to AES-256 for optimal post-quantum security margin against Grover's algorithm"
        else:
            action = f"Maintain {alg}; configuration provides adequate quantum and classical resistance"

    return action, wave


def resolve_dependencies(records: List[Dict[str, Any]]) -> Dict[str, str]:
    """Infers prerequisite dependencies between assets.

    For instance, leaf certificates in a service depend on the internal CA or HSM key
    within that service or enterprise migrating first.
    """
    deps: Dict[str, str] = {}
    service_cas: Dict[str, str] = {}

    # Step 1: Identify Root / CA / HSM signing keys
    for r in records:
        aid = r.get("asset_id", "")
        asset_type = (r.get("asset_type") or "").strip().lower()
        usage = (r.get("usage") or "").strip().lower()
        service = (r.get("service") or "").strip().lower()
        if asset_type == "hsm_key" or "ca" in usage or "root" in usage:
            service_cas[service] = aid
            if "default" not in service_cas:
                service_cas["default"] = aid

    # Step 2: Associate certificates and dependent clients with their CA
    for r in records:
        aid = r.get("asset_id", "")
        asset_type = (r.get("asset_type") or "").strip().lower()
        service = (r.get("service") or "").strip().lower()
        if asset_type == "certificate":
            if service in service_cas and service_cas[service] != aid:
                deps[aid] = service_cas[service]
            elif "default" in service_cas and service_cas["default"] != aid:
                deps[aid] = service_cas["default"]
            else:
                deps[aid] = ""
        else:
            deps[aid] = ""

    return deps


def prioritize_inventory(records: List[Dict[str, Any]], labels: List[str]) -> List[Dict[str, Any]]:
    """Runs end-to-end prioritization, ranking, wave assignment, and dependency resolution."""
    scored_items = []
    deps = resolve_dependencies(records)

    for r, label in zip(records, labels):
        score, rationale = calculate_risk_score(r, label)
        action, wave = determine_recommendation_and_wave(r, label, score)
        aid = r.get("asset_id", "")
        scored_items.append({
            "asset_id": aid,
            "predicted_label": label,
            "priority_score": score,
            "recommended_action": action,
            "migration_wave": wave,
            "depends_on": deps.get(aid, ""),
            "rationale": rationale,
        })

    # Sort descending by priority_score to compute priority_rank
    # Standard competition ranking: ties receive the same rank
    sorted_by_score = sorted(scored_items, key=lambda x: x["priority_score"], reverse=True)
    current_rank = 1
    for i, item in enumerate(sorted_by_score):
        if i > 0 and item["priority_score"] < sorted_by_score[i - 1]["priority_score"]:
            current_rank = i + 1
        item["priority_rank"] = current_rank

    # Reorder back to original inventory order
    order_map = {r["asset_id"]: i for i, r in enumerate(records)}
    scored_items.sort(key=lambda x: order_map.get(x["asset_id"], 0))

    return scored_items
