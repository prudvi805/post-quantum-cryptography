"""Core Cryptographic Inventory Classifier for QFF 2026 Phase 2 (PS-P2).

Implements the official labeling rules, rule precedence, contradiction checks,
and alias mappings defined in SCHEMA.md.
"""
from __future__ import annotations

import re
from typing import Any, Dict

# Official 6 labels defined in SCHEMA.md
LABELS = [
    "QUANTUM_VULNERABLE",
    "QUANTUM_RESISTANT",
    "HYBRID",
    "SYMMETRIC_OR_HASH",
    "LEGACY_BROKEN",
    "UNKNOWN",
]

# Set of unidentifiable algorithm strings that trigger UNKNOWN
UNIDENTIFIABLE_ALGS = {
    "",
    "unknown",
    "vendor default",
    "vendor-managed",
    "proprietary",
    "custom xor scheme",
}

# Pure symmetric / hash names that contradict digital_signature / key_establishment
PURE_SYMMETRIC_OR_HASH = [
    "SHA-256", "SHA256", "SHA-384", "SHA-512", "SHA3-256", "SHA3-384", "SHA3-512",
    "AES-128", "AES-192", "AES-256", "AES-256-GCM", "AES-128-GCM", "CHACHA20-POLY1305",
    "HMAC-SHA256", "HKDF-SHA256", "PBKDF2-HMAC-SHA256", "SCRYPT", "ARGON2ID", "ARGON2",
    "MD5", "SHA-1", "SHA1", "3DES", "DES", "RC4", "TDEA"
]

# Public-key indicators that contradict hash / symmetric_encryption
PUBLIC_KEY_TOKENS = [
    "RSA", "DH", "ECDH", "ECDSA", "ED25519", "X25519",
    "ML-KEM", "ML-DSA", "SLH-DSA", "XMSS", "LMS", "KYBER", "DILITHIUM"
]

# Recognized Hybrid indicators
HYBRID_INDICATORS = [
    "X25519MLKEM768", "X25519+ML-KEM", "SECP256R1MLKEM768", "P-256+ML-KEM",
    "ECDSA-P256+ML-DSA-44", "X25519KYBER768", "+ML-KEM", "+ML-DSA",
    "MLKEM768X25519", "CURVE25519+ML-KEM"
]

# Classical Public Key indicators (QUANTUM_VULNERABLE)
QV_TERMS = [
    "RSA", "ECDHE", "ECDH", "ECDSA", "EDDSA",
    "ED25519", "ED448", "X25519", "CURVE25519", "X448",
    "SECP256R1", "SECP384R1", "PRIME256V1", "P-256", "P-384",
    "RS256", "MODP", "FFDHE"
]

# Post-Quantum Public Key indicators (QUANTUM_RESISTANT)
QR_TERMS = [
    "ML-KEM", "ML-DSA", "SLH-DSA", "FN-DSA", "FALCON",
    "LMS", "XMSS", "HQC", "KYBER", "DILITHIUM", "SPHINCS"
]

# Classically Broken Symmetric/Hash indicators (LEGACY_BROKEN)
LB_TERMS = [
    "MD5", "SHA-1", "SHA1", "3DES", "TDEA", "DES", "RC4"
]

# Adequate Symmetric/Hash indicators (SYMMETRIC_OR_HASH)
SH_TERMS = [
    "AES", "CHACHA20", "SHA-2", "SHA2", "SHA-3", "SHA3",
    "SHA", "HMAC", "HKDF", "PBKDF2", "SCRYPT", "ARGON2"
]


def classify_record(record: Dict[str, Any]) -> str:
    """Classifies an enterprise inventory record into one of the 6 official labels.

    Follows the strict precedence order from SCHEMA.md:
    1. UNKNOWN first (unidentifiable, missing, or contradictory fields)
    2. HYBRID (classical public key combined with PQC)
    3. QUANTUM_VULNERABLE (classical public key at any key size)
    4. QUANTUM_RESISTANT (PQC public key only)
    5. LEGACY_BROKEN (classically broken or deprecated symmetric/hash)
    6. SYMMETRIC_OR_HASH (adequate symmetric ciphers, hashes, MACs, KDFs)
    """
    raw_alg = (record.get("algorithm") or "").strip()
    primitive = (record.get("primitive") or "").strip().lower()
    param = (record.get("key_size_or_parameter_set") or "").strip()

    # -------------------------------------------------------------
    # 1. UNKNOWN First: Unidentifiable or Contradictory Information
    # -------------------------------------------------------------
    if not raw_alg or raw_alg.lower() in UNIDENTIFIABLE_ALGS:
        return "UNKNOWN"

    alg_upper = raw_alg.upper()
    alg_clean = re.sub(r"[^A-Z0-9\+\-\_]", "", alg_upper)

    # 1a. Contradiction: Hash / Symmetric algorithm declared as public-key operation
    # (e.g. SHA-256 for release signing, AES-256 for contract signing)
    is_pure_sym_hash = any(
        alg_clean == re.sub(r"[^A-Z0-9\+\-\_]", "", s.upper())
        for s in PURE_SYMMETRIC_OR_HASH
    )
    if is_pure_sym_hash and primitive in (
        "digital_signature",
        "key_establishment",
        "public_key_encryption",
    ):
        return "UNKNOWN"

    # 1b. Contradiction: Public-key algorithm declared as hash / symmetric_encryption
    # (e.g. RSA for hash)
    is_pk = any(p in alg_upper for p in PUBLIC_KEY_TOKENS) or bool(
        re.search(r"\bDSA\b", alg_upper)
    )
    if is_pk and primitive in ("hash", "symmetric_encryption", "mac", "kdf"):
        return "UNKNOWN"

    # 1c. Contradiction: Impossible parameter set
    if "ML-KEM" in alg_upper or "KYBER" in alg_upper:
        if param in ("2048", "4096"):
            return "UNKNOWN"
    if "AES" in alg_upper and param == "2048":
        return "UNKNOWN"
    if "ML-DSA" in alg_upper and "ML-KEM" in param.upper():
        return "UNKNOWN"

    # -------------------------------------------------------------
    # 2. HYBRID: Classical + PQC public-key mechanism combined
    # -------------------------------------------------------------
    if any(h in alg_clean or h in alg_upper for h in HYBRID_INDICATORS):
        return "HYBRID"

    # Pattern check: combinations with + or / or -
    if ("+" in raw_alg or "/" in raw_alg or "-" in raw_alg) and (
        any(p in alg_upper for p in ["ML-KEM", "ML-DSA", "KYBER", "DILITHIUM", "MLKEM"])
        and any(c in alg_upper for c in ["X25519", "P256", "P-256", "SECP", "ECDSA", "RSA"])
    ):
        return "HYBRID"

    # -------------------------------------------------------------
    # 3. QUANTUM_VULNERABLE: Classical public-key mechanism
    # -------------------------------------------------------------
    is_qv = any(t in alg_upper for t in QV_TERMS)
    # Match ES256 / ES384 / ES512 without false-matching AES256
    if not is_qv and re.search(r"(?<![A-Z0-9])ES(?:256|384|512)\b", alg_upper):
        is_qv = True
    # Match DH / FFDH
    if not is_qv and re.search(r"\bDH\b", alg_upper):
        is_qv = True
    # Match DSA without matching ML-DSA or SLH-DSA
    if not is_qv and re.search(r"(?<![A-Z0-9\-])DSA\b", alg_upper):
        is_qv = True

    if is_qv:
        return "QUANTUM_VULNERABLE"

    # -------------------------------------------------------------
    # 4. QUANTUM_RESISTANT: Post-Quantum public-key mechanism only
    # -------------------------------------------------------------
    if any(t in alg_upper for t in QR_TERMS):
        return "QUANTUM_RESISTANT"

    # -------------------------------------------------------------
    # 5. LEGACY_BROKEN: Classically broken symmetric / hash
    # -------------------------------------------------------------
    for lb in LB_TERMS:
        if lb == "DES":
            if re.search(r"\b3?DES\b", alg_upper):
                return "LEGACY_BROKEN"
        elif lb in alg_upper:
            return "LEGACY_BROKEN"

    # -------------------------------------------------------------
    # 6. SYMMETRIC_OR_HASH: Adequate symmetric / hash / MAC / KDF
    # -------------------------------------------------------------
    if any(t in alg_upper for t in SH_TERMS):
        return "SYMMETRIC_OR_HASH"

    # Fallback to UNKNOWN if not identifiable
    return "UNKNOWN"
