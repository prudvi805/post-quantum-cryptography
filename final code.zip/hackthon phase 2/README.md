# Team Q-Safe — PS-P2: Enterprise Cryptographic Inventory and Migration Planner

**Team members:** Prudvi Narayana (Lead & Cryptographic Engineer), Team Contributors  
**Problem statement:** PS-P2 — Enterprise Cryptographic Inventory and Migration Planner  
**Phase 1 work reused:** yes (Phase 1 static code analyzer reused and adapted into multi-language ingestion front-end `src/repo_scanner.py`)

---

## 1. Summary

This repository delivers an enterprise-grade, offline, zero-dependency Cryptographic Inventory Classification and Migration Planning System designed for **PS-P2**. It ingests enterprise asset inventories formatted according to `SCHEMA.md`, enforces a deterministic 6-stage rule precedence engine to eliminate unsafe assumptions, and achieves **1.0000 Macro-F1 (100.0% accuracy)** across all 6 official NIST classes on `inventory_dev.csv` using the official `evaluate.py`. It prioritizes operational risks using an auditable multi-factor scoring model (0–100) based on Mosca's Theorem ($x + y > z$), data retention, internet exposure, business criticality, and dependency graphs. Reusing our Phase 1 static analysis foundation, it also provides an automated code ingestion scanner that discovered 100% of planted cryptographic assets across Python, Java, C, and OpenSSH configs in `sample_repo/`. The pipeline processes 1,000 records in **0.031s** (~31,590 records/sec), outperforming the organizer 5-minute requirement by over **9,400x**.

---

## 2. Setup — exact steps

The core tool (`run_inventory.py`), evaluator (`evaluate.py`), and test suite use standard Python 3.10+ with **zero mandatory external dependencies** to guarantee 100% offline reproducibility for judges.

```bash
# 1. Create and activate a virtual environment (Python 3.10 - 3.13)
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

# 2. Install optional platform and reference libraries
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

# 3. Verify environment and inspect recorded Platform A info
python common/env_check.py
```

---

## 3. Reproduce the principal results — exact commands

All commands run directly from the repository root:

```bash
# Command 1: Mandatory CLI Interface on Development Set (produces results/predictions_dev.csv)
python run_inventory.py --input inventory_dev.csv --output results/predictions_dev.csv

# Command 2: Official Scorer (reproduces 1.0000 Macro-F1 and 0 Unsafe-Unknowns)
python evaluate.py --pred results/predictions_dev.csv --labels inventory_dev_labels.csv

# Command 3: Side-by-side comparative benchmark against official baseline
python src/benchmark_comparison.py

# Command 4: Scalability stress test on 1,000 synthetic records
python src/synthetic_generator.py

# Command 5: Automated multi-language code scanner front-end (Phase 1 integration)
python -c "from src.repo_scanner import export_repo_inventory; export_repo_inventory('sample_repo', 'results/sample_repo_inventory.csv')"
python run_inventory.py --input results/sample_repo_inventory.csv --output results/sample_repo_predictions.csv
```

**Expected run time on Platform A:** **< 0.1 min** (entire reproduction suite executes in < 2 seconds).

---

## 4. Platforms used

| Platform | Machine / profile | Evidence file |
|---|---|---|
| **A** | Windows 11 (AMD64), Intel Core i7 / 8 logical cores, 16 GB RAM, Python 3.10+ | [`platform_A_info.json`](platform_A_info.json) |
| **B (if used)** | *Not needed for PS-P2 data analysis track (per Guide §2)* | N/A |
| **D (optional)**| *Not needed for PS-P2 (per Guide §2)* | N/A |

---

## 5. Libraries and versions

Pinned in [`requirements.txt`](requirements.txt):
- `python >= 3.10` (Tested on 3.10, 3.14, 3.15)
- `cryptography == 50.0.2` (Reference PQC & classical primitives)
- `pqcrypto == 1.0.0` (SLH-DSA & ML-KEM bindings)
- `psutil >= 5.9` (Hardware inspection and timing measurements)
- `numpy >= 1.24`, `pandas >= 2.0`, `matplotlib >= 3.7` (Analysis & figures)

*Note: `run_inventory.py` uses strictly Python standard library (`csv`, `re`, `argparse`, `sys`, `pathlib`) for guaranteed offline zero-failure execution by judges.*

---

## 6. Tests (command, expected behaviour, recorded result)

### Command:
```bash
python -m unittest discover -s tests -p "test_*.py" -v
```

### Expected Behaviour:
Runs all 13 automated unit, contract, and robustness tests:
- `test_classifier.py` (9 tests): Validates official 6-stage rule precedence, contradiction checks (hash-as-signature, impossible key sizes), alias mapping, and hybrid detection.
- `test_prioritization.py` (3 tests): Validates 0–100 score bounds, non-zero review priority for `UNKNOWN`, and distinct priority differentiation across assets with identical algorithms.
- `test_cli.py` (1 test): Validates the mandatory CLI interface (`run_inventory.py --input --output`), output column formatting, and non-empty rationale fields.

### Recorded Result:
```text
Ran 13 tests in 0.418s
OK (All 13 tests passed, 0 failures, 0 errors)
```

---

## 7. Results (tables / figures, with links to files in results/)

### Official Evaluation Metrics on Development Set (150 records)
Scored using official `evaluate.py`:
- Link to raw evaluation output: [`results/evaluation_dev.json`](results/evaluation_dev.json)
- Link to predicted CSV: [`results/predictions_dev.csv`](results/predictions_dev.csv)

| Metric | Result | Benchmark Baseline | Delta / Improvement |
|---|---|---|---|
| **Overall Accuracy** | **1.0000 (100.0%)** | 0.5867 (58.67%) | **+41.33%** |
| **Headline Macro-F1** | **1.0000** | 0.4757 | **+0.5243** |
| **UNKNOWN Recall** | **1.0000** | 0.4667 | **+53.33%** |
| **Unsafe-Unknown Count** | **0** | 14 | **-14 (100% eliminated)** |
| **Hash-as-Public-Key** | **0** | 0 | **0 (Zero misclassifications)** |
| **Hybrid F1** | **1.0000** | 0.0000 | **+1.0000** |

### Scalability Stress Test (1,000 synthetic enterprise assets)
- Evidence file: [`results/benchmark_1000.json`](results/benchmark_1000.json)
- Predictions output: [`results/synthetic_1000_predictions.csv`](results/synthetic_1000_predictions.csv)
- **Time Elapsed:** **0.031 seconds** (Organizer threshold: 300 seconds)
- **Throughput:** **31,590 records/second** (**>9,400x faster** than the 5-minute requirement)

### Multi-Language Code Scanner Validation (sample_repo/)
- Discovered Inventory: [`results/sample_repo_inventory.csv`](results/sample_repo_inventory.csv)
- Generated Predictions: [`results/sample_repo_predictions.csv`](results/sample_repo_predictions.csv)
- Discovered 18/18 planted assets across Python, Java, C, and OpenSSH (100% match with [`sample_repo_expected.csv`](sample_repo_expected.csv)).

---

## 8. Baseline used

The baseline is the organizer-supplied `baseline_classifier.py` (a naive keyword-matching classifier). 

### Headline Comparison ([`results/benchmark_comparison.csv`](results/benchmark_comparison.csv)):
```text
======================================================================
PS-P2 BENCHMARK COMPARISON: OUR TOOL vs BASELINE CLASSIFIER
======================================================================
  Overall Accuracy         | Baseline: 0.5867   | Our Tool: 1.0000   | +41.33%
  Headline Macro-F1        | Baseline: 0.4757   | Our Tool: 1.0000   | +0.5243
  UNKNOWN Recall           | Baseline: 0.4667   | Our Tool: 1.0000   | +53.33%
  Unsafe-Unknown Count     | Baseline: 14       | Our Tool: 0        | -14 (100% eliminated)
  Hash-as-Public-Key       | Baseline: 0        | Our Tool: 0        | 0 (zero error)
  Hybrid F1                | Baseline: 0.0000   | Our Tool: 1.0000   | +1.0000
======================================================================
```

Why the baseline fails:
1. Misses composite hybrid combinations (`X25519MLKEM768`), scoring 0.0000 F1 on `HYBRID`.
2. Silently misclassifies unidentifiable/contradictory records into safe categories (14 unsafe-unknown violations).
3. Lacks contradiction detection and contextual risk prioritization.

---

## 9. Known limitations

1. **Static AST Parameter Inference:** When cryptographic parameters are loaded at runtime from dynamic environment variables or configuration files, static code analysis may extract blank key sizes, falling back to conservative `UNKNOWN` or default risk ratings.
2. **Automated Remediation:** The current release infers dependencies and outputs actionable migration waves, targets, and rationales; automated AST code refactoring and PR generation are planned for future releases.
3. **Hardware-Bound Assets:** HSMs and smart cards cannot be migrated via software updates alone and require physical device lifecycle management.
