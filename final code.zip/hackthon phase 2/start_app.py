#!/usr/bin/env python3
"""One-Click Full-Stack Application Launcher.

Starts the Python Backend and serves the Frontend at http://localhost:8080.
Standard library only. No pip install required.
"""
import os
import sys
import webbrowser
from pathlib import Path

# Add project root to sys.path
ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.server import run_server

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    # Optional auto-open browser
    if "--no-browser" not in sys.argv:
        try:
            webbrowser.open(f"http://localhost:{port}")
        except Exception:
            pass
    run_server(port)
