"""Cryptographic Service Layer connecting Core Engines with the Web API."""
from __future__ import annotations

import csv
import json
import time
from pathlib import Path
from typing import Any, Dict, List

# Core engines
from src.classifier import classify_record
from src.prioritizer import prioritize_inventory
from src.repo_scanner import scan_repository


def process_records(records: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Classifies and prioritizes an inventory list of records."""
    t0 = time.perf_counter()
    labels = [classify_record(r) for r in records]
    predictions = prioritize_inventory(records, labels)
    elapsed_ms = round((time.perf_counter() - t0) * 1000, 2)
    summary = compute_summary(records, predictions)

    return {
        "record_count": len(records),
        "processing_time_ms": elapsed_ms,
        "summary": summary,
        "records": predictions,
    }


def scan_codebase(repo_dir: Path | str) -> Dict[str, Any]:
    """Runs Phase 1 static analysis scanner and returns classified findings."""
    t0 = time.perf_counter()
    findings = scan_repository(repo_dir)
    labels = [classify_record(r) for r in findings]
    predictions = prioritize_inventory(findings, labels)
    elapsed_ms = round((time.perf_counter() - t0) * 1000, 2)
    summary = compute_summary(findings, predictions)

    return {
        "repo_path": str(repo_dir),
        "discovered_count": len(findings),
        "processing_time_ms": elapsed_ms,
        "summary": summary,
        "records": predictions,
    }


def compute_summary(records: List[Dict], predictions: List[Dict]) -> Dict[str, Any]:
    """Compute aggregate summary statistics for the frontend dashboard."""
    label_counts: Dict[str, int] = {}
    wave_counts: Dict[str, int] = {"1": 0, "2": 0, "3": 0, "review": 0}
    scores: List[float] = []

    for p in predictions:
        lbl = p.get("predicted_label", "UNKNOWN")
        label_counts[lbl] = label_counts.get(lbl, 0) + 1

        wv = str(p.get("migration_wave", "review")).lower()
        if wv in wave_counts:
            wave_counts[wv] += 1
        else:
            wave_counts["review"] += 1

        try:
            scores.append(float(p.get("priority_score", 0)))
        except Exception:
            pass

    avg_score = round(sum(scores) / len(scores), 1) if scores else 0.0
    max_score = max(scores) if scores else 0.0

    return {
        "total_assets":          len(predictions),
        "label_distribution":    label_counts,
        "wave_distribution":     wave_counts,
        "average_risk_score":    avg_score,
        "max_risk_score":        max_score,
        # Convenience counts used by KPI cards
        "shor_vulnerable_count": label_counts.get("QUANTUM_VULNERABLE", 0),
        "legacy_broken_count":   label_counts.get("LEGACY_BROKEN", 0),
        "quantum_ready_count":   label_counts.get("QUANTUM_RESISTANT", 0),
        "hybrid_count":          label_counts.get("HYBRID", 0),
        "review_required_count": label_counts.get("UNKNOWN", 0),
        "symmetric_hash_count":  label_counts.get("SYMMETRIC_OR_HASH", 0),
    }
