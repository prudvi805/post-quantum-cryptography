"""API Routes and Dispatcher for the Web Application."""
from __future__ import annotations

import csv
import io
import json
from pathlib import Path
from typing import Any, Dict

from backend.services import process_records, scan_codebase


def get_status(root_dir: Path) -> Dict[str, Any]:
    info_path = root_dir / "platform_A_info.json"
    info = {}
    if info_path.exists():
        try:
            info = json.loads(info_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {
        "status": "ready",
        "problem_statement": "PS-P2: Enterprise Cryptographic Inventory & Migration Planner",
        "version": "1.0.0",
        "offline_mode": True,
        "platform": info,
    }


def load_sample_dataset(root_dir: Path, dataset_name: str) -> Dict[str, Any]:
    file_map = {
        "dev":       root_dir / "inventory_dev.csv",
        "repo":      root_dir / "results" / "sample_repo_inventory.csv",
        "synthetic": root_dir / "results" / "synthetic_1000.csv",
    }
    target = file_map.get(dataset_name, root_dir / "inventory_dev.csv")
    if not target.exists():
        raise FileNotFoundError(f"Sample file '{target.name}' not found at {target}")

    with open(target, mode="r", encoding="utf-8", errors="replace") as f:
        reader = csv.DictReader(f)
        records = list(reader)

    result = process_records(records)
    result["dataset"]  = dataset_name
    result["filename"] = target.name
    return result


def classify_payload(body: bytes) -> Dict[str, Any]:
    data = json.loads(body.decode("utf-8"))
    if "csv_text" in data:
        f       = io.StringIO(data["csv_text"])
        reader  = csv.DictReader(f)
        records = list(reader)
    elif "records" in data:
        records = data["records"]
    else:
        raise ValueError("Expected 'csv_text' or 'records' in request body")

    if not records:
        raise ValueError("No records to classify")

    return process_records(records)


def run_repo_scanner(root_dir: Path, custom_path: str = "") -> Dict[str, Any]:
    target_dir = Path(custom_path) if custom_path else (root_dir / "sample_repo")
    if not target_dir.exists():
        target_dir = root_dir / "sample_repo"
    return scan_codebase(target_dir)


def get_benchmark_comparison(root_dir: Path) -> Dict[str, Any]:
    comparison_csv = root_dir / "results" / "benchmark_comparison.csv"
    rows = []
    if comparison_csv.exists():
        with open(comparison_csv, mode="r", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                # Normalize column names to what the frontend expects:
                # { metric, our_model, baseline, delta }
                metric    = row.get("metric",    row.get("Metric",    ""))
                our_val   = row.get("our_tool",  row.get("our_model", row.get("Our Model", "")))
                base_val  = row.get("baseline",  row.get("Baseline",  ""))
                improve   = row.get("improvement", row.get("delta", row.get("Delta", "")))

                # Try to compute numeric delta if raw values are numeric
                try:
                    delta = float(our_val) - float(base_val)
                except Exception:
                    delta = None

                rows.append({
                    "metric":     metric,
                    "our_model":  our_val,
                    "baseline":   base_val,
                    "delta":      delta,
                    "improvement": improve,
                })

    eval_dev  = root_dir / "results" / "evaluation_dev.json"
    eval_base = root_dir / "results" / "evaluation_baseline.json"
    dev_data  = json.loads(eval_dev.read_text(encoding="utf-8"))  if eval_dev.exists()  else {}
    base_data = json.loads(eval_base.read_text(encoding="utf-8")) if eval_base.exists() else {}

    return {
        "comparison":          rows,          # key the frontend uses
        "our_evaluation":      dev_data,
        "baseline_evaluation": base_data,
    }
