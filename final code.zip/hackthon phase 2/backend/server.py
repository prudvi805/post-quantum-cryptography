"""HTTP Server for Q-Safe — serves frontend static files + REST API."""
from __future__ import annotations

import json
import os
import sys
import traceback
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

# Ensure project root in sys.path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.routes import (
    classify_payload,
    get_benchmark_comparison,
    get_status,
    load_sample_dataset,
    run_repo_scanner,
)

FRONTEND_DIR = ROOT / "frontend"


class QSafeServerHandler(SimpleHTTPRequestHandler):
    """Serves frontend static assets and REST API endpoints."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(FRONTEND_DIR), **kwargs)

    # ─── helpers ─────────────────────────────────────────────────────────────
    def send_json(self, data, status: int = 200):
        try:
            body = json.dumps(data, indent=2, default=str).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass  # Client disconnected — that's fine

    def log_message(self, fmt, *args):
        # Suppress noisy default logging; only print errors
        status = args[1] if len(args) > 1 else "?"
        if not str(status).startswith("2"):
            super().log_message(fmt, *args)
        else:
            print(f"  {self.command} {self.path}  →  {status}")

    # ─── CORS pre-flight ─────────────────────────────────────────────────────
    def do_OPTIONS(self):
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    # ─── GET ─────────────────────────────────────────────────────────────────
    def do_GET(self):
        parsed = urlparse(self.path)
        path  = parsed.path
        query = parse_qs(parsed.query)

        try:
            if path == "/api/status":
                self.send_json(get_status(ROOT))

            elif path == "/api/load_sample":
                dataset = query.get("dataset", ["dev"])[0]
                self.send_json(load_sample_dataset(ROOT, dataset))

            elif path == "/api/benchmark":
                self.send_json(get_benchmark_comparison(ROOT))

            elif path == "/api/export_predictions":
                pred_path = ROOT / "results" / "predictions_dev.csv"
                if not pred_path.exists():
                    self.send_json({"error": "predictions_dev.csv not found"}, 404)
                    return
                content = pred_path.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "text/csv; charset=utf-8")
                self.send_header("Content-Disposition", 'attachment; filename="predictions.csv"')
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                self.wfile.write(content)

            elif path == "/" or not (FRONTEND_DIR / path.lstrip("/")).exists():
                # SPA fallback → serve index.html
                index_path = FRONTEND_DIR / "index.html"
                if index_path.exists():
                    content = index_path.read_bytes()
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(content)))
                    self.end_headers()
                    self.wfile.write(content)
                else:
                    self.send_error(404, "frontend/index.html not found.")
            else:
                super().do_GET()

        except (BrokenPipeError, ConnectionResetError):
            pass
        except FileNotFoundError as e:
            self.send_json({"error": str(e)}, 404)
        except Exception as e:
            traceback.print_exc()
            self.send_json({"error": str(e)}, 500)

    # ─── POST ────────────────────────────────────────────────────────────────
    def do_POST(self):
        parsed = urlparse(self.path)
        path  = parsed.path

        length = int(self.headers.get("Content-Length", 0))
        body   = self.rfile.read(length) if length > 0 else b""

        try:
            if path == "/api/classify":
                self.send_json(classify_payload(body))

            elif path == "/api/scan_repo":
                custom_path = ""
                if body:
                    try:
                        custom_path = json.loads(body.decode("utf-8")).get("path", "")
                    except Exception:
                        pass
                self.send_json(run_repo_scanner(ROOT, custom_path))

            else:
                self.send_json({"error": f"Endpoint '{path}' not found"}, 404)

        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            traceback.print_exc()
            self.send_json({"error": str(e)}, 500)


def run_server(port: int = 8080):
    print("=" * 60)
    print("  Q-Safe  |  Enterprise Cryptographic Inventory")
    print("  PS-P2   |  Qiskit Fall Fest 2026")
    print("=" * 60)
    print(f"  Open in browser:  http://localhost:{port}")
    print(f"  Frontend:  {FRONTEND_DIR}")
    print(f"  Backend:   {ROOT / 'backend'}")
    print("  Press Ctrl+C to stop.")
    print("=" * 60)

    server = ThreadingHTTPServer(("0.0.0.0", port), QSafeServerHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server...")
        server.server_close()


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    run_server(port)
