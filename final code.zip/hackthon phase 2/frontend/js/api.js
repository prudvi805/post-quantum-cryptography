/**
 * Q-Safe API Service — communicates with the Python backend.
 */
const API = {
  baseUrl: '',

  async getStatus() {
    const res = await fetch(`${this.baseUrl}/api/status`);
    if (!res.ok) throw new Error(`Status check failed: ${res.statusText}`);
    return res.json();
  },

  async loadSample(dataset = 'dev') {
    const res = await fetch(`${this.baseUrl}/api/load_sample?dataset=${encodeURIComponent(dataset)}`);
    if (!res.ok) throw new Error(`Failed to load '${dataset}': ${res.statusText}`);
    const data = await res.json();
    if (data.error) throw new Error(data.error);
    return data;
  },

  async classifyCSV(csvText) {
    const res = await fetch(`${this.baseUrl}/api/classify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ csv_text: csvText })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error);
    return data;
  },

  async scanRepo(customPath = '') {
    const res = await fetch(`${this.baseUrl}/api/scan_repo`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: customPath })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error);
    return data;
  },

  async getBenchmark() {
    const res = await fetch(`${this.baseUrl}/api/benchmark`);
    if (!res.ok) throw new Error(`Benchmark failed: ${res.statusText}`);
    return res.json();
  },

  exportPredictionsUrl() {
    return `${this.baseUrl}/api/export_predictions`;
  }
};
