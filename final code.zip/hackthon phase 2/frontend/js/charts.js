/**
 * Q-Safe Chart Service — wraps Chart.js for reusable, destroyable charts.
 */
const ChartService = {
  _charts: {},

  _destroy(id) {
    if (this._charts[id]) {
      this._charts[id].destroy();
      delete this._charts[id];
    }
  },

  renderCategoryDonut(canvasId, dist) {
    this._destroy(canvasId);
    const canvas = document.getElementById(canvasId);
    if (!canvas || !dist) return;
    const labels = Object.keys(dist);
    const values = Object.values(dist);
    const COLORS = {
      QUANTUM_VULNERABLE: '#f87171',
      QUANTUM_READY:      '#34d399',
      HYBRID:             '#fbbf24',
      SHOR_HARDENED:      '#818cf8',
      LEGACY_BROKEN:      '#fb923c',
      REVIEW_REQUIRED:    '#94a3b8',
    };
    const colors = labels.map(l => COLORS[l] || '#6b7280');
    this._charts[canvasId] = new Chart(canvas, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{ data: values, backgroundColor: colors, borderColor: '#111827', borderWidth: 2 }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { position: 'right', labels: { color: '#9ca3af', font: { size: 11 }, padding: 14 } }
        }
      }
    });
  },

  renderWaveBar(canvasId, dist) {
    this._destroy(canvasId);
    const canvas = document.getElementById(canvasId);
    if (!canvas || !dist) return;
    const WAVE_COLORS = { '1': '#f87171', '2': '#fbbf24', '3': '#60a5fa', 'review': '#94a3b8' };
    const labels = Object.keys(dist);
    const values = Object.values(dist);
    const colors = labels.map(l => WAVE_COLORS[String(l)] || '#6b7280');
    this._charts[canvasId] = new Chart(canvas, {
      type: 'bar',
      data: {
        labels: labels.map(l => l === 'review' ? 'Review' : `Wave ${l}`),
        datasets: [{ label: 'Assets', data: values, backgroundColor: colors, borderRadius: 6 }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { color: '#9ca3af' }, grid: { color: '#1f2937' } },
          y: { ticks: { color: '#9ca3af', precision: 0 }, grid: { color: '#1f2937' } }
        }
      }
    });
  }
};
