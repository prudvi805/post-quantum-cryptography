/**
 * Q-Safe Application Controller
 */

let allRecords = [];
let currentSummary = {};

/* ── Bootstrap ─────────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  initListeners();
  loadDataset('dev');   // auto-load the dev set on startup
});

function initListeners() {
  document.getElementById('csvFileInput')?.addEventListener('change', handleFileUpload);
  document.getElementById('searchInput')?.addEventListener('input', applyFilters);
  document.getElementById('filterLabel')?.addEventListener('change', applyFilters);
  document.getElementById('filterWave')?.addEventListener('change', applyFilters);
}

/* ── Dataset Loading ────────────────────────────────────────────────────── */
async function loadDataset(name) {
  showAlert(`Loading '${name}' dataset...`, 'info');
  try {
    const data = await API.loadSample(name);
    allRecords     = data.records  || [];
    currentSummary = data.summary  || {};
    updateKPIs();
    applyFilters();
    showAlert(`Loaded ${data.record_count} records in ${data.processing_time_ms} ms.`, 'success');
  } catch (err) {
    showAlert(`Error loading dataset: ${err.message}`, 'error');
  }
}

async function handleFileUpload(e) {
  const file = e.target.files[0];
  if (!file) return;
  showAlert(`Classifying '${file.name}'...`, 'info');
  const reader = new FileReader();
  reader.onload = async (evt) => {
    try {
      const data = await API.classifyCSV(evt.target.result);
      allRecords     = data.records  || [];
      currentSummary = data.summary  || {};
      updateKPIs();
      applyFilters();
      showAlert(`Classified ${data.record_count} records.`, 'success');
    } catch (err) {
      showAlert(`Upload failed: ${err.message}`, 'error');
    }
  };
  reader.readAsText(file);
}

/* ── KPI + Charts ───────────────────────────────────────────────────────── */
function updateKPIs() {
  const s = currentSummary;
  setText('kpiTotal',  s.total_assets          || 0);
  setText('kpiQV',     s.shor_vulnerable_count  || 0);
  setText('kpiQR',     s.quantum_ready_count    || 0);
  setText('kpiHybrid', s.hybrid_count           || 0);
  setText('kpiLB',     s.legacy_broken_count    || 0);
  setText('kpiScore',  s.average_risk_score     || 0);
  setText('tabCountBadge', s.total_assets       || 0);

  ChartService.renderCategoryDonut('categoryChart', s.label_distribution);
  ChartService.renderWaveBar('waveChart', s.wave_distribution);

  // Top urgent list (Wave 1)
  const listEl = document.getElementById('topUrgentList');
  if (listEl) {
    const urgent = allRecords.filter(r => String(r.migration_wave) === '1').slice(0, 5);
    if (urgent.length === 0) {
      listEl.innerHTML = '<p class="text-gray-500 text-xs text-center py-4">No Wave 1 assets found.</p>';
    } else {
      listEl.innerHTML = urgent.map(r => `
        <div onclick='openModal(${JSON.stringify(r).replace(/'/g, "&#39;")})' class="flex items-center justify-between p-3 rounded-lg bg-gray-950 border border-gray-800 hover:border-gray-600 cursor-pointer transition">
          <div class="flex items-center gap-2">
            <span class="font-mono font-bold text-blue-400 text-xs">${r.asset_id}</span>
            <span class="text-gray-300 text-xs truncate max-w-[150px]">${r.algorithm || 'Unknown'}</span>
          </div>
          <span class="font-mono text-red-400 text-xs font-bold">Score: ${r.priority_score}</span>
        </div>
      `).join('');
    }
  }
}

function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

/* ── Inventory Table ────────────────────────────────────────────────────── */
function applyFilters() {
  const q    = (document.getElementById('searchInput')?.value || '').toLowerCase();
  const cat  = document.getElementById('filterLabel')?.value  || 'ALL';
  const wave = document.getElementById('filterWave')?.value   || 'ALL';

  const filtered = allRecords.filter(r => {
    const matchQ = !q || [r.asset_id, r.algorithm, r.service, r.recommended_action, r.rationale]
                          .some(f => (f || '').toLowerCase().includes(q));
    const matchC = cat  === 'ALL' || r.predicted_label === cat;
    const matchW = wave === 'ALL' || String(r.migration_wave).toLowerCase() === wave.toLowerCase();
    return matchQ && matchC && matchW;
  });

  renderTable(filtered);
  setText('filteredCount', `${filtered.length} records`);
}

function renderTable(records) {
  const tbody = document.getElementById('inventoryTableBody');
  if (!tbody) return;

  if (records.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="py-8 text-center text-gray-500">No records match the current filters.</td></tr>';
    return;
  }

  tbody.innerHTML = records.map(r => {
    const labelKey = (r.predicted_label || 'unknown').toLowerCase().replace(/_/g, '-');
    const scoreColor = r.priority_score >= 70 ? 'text-red-400' : r.priority_score >= 40 ? 'text-yellow-400' : 'text-emerald-400';
    const waveKey = String(r.migration_wave).toLowerCase();
    const waveColor = waveKey === '1' ? 'text-red-400' : waveKey === '2' ? 'text-yellow-400' : waveKey === '3' ? 'text-blue-400' : 'text-gray-400';
    const safeR = JSON.stringify(r).replace(/'/g, "&#39;");
    return `
      <tr class="hover:bg-gray-800/40 transition border-b border-gray-800/60">
        <td class="py-3 px-4 font-mono font-bold text-blue-400 text-xs">${r.asset_id}</td>
        <td class="py-3 px-4"><span class="badge badge-${labelKey}">${r.predicted_label}</span></td>
        <td class="py-3 px-4 text-gray-200 font-mono text-xs">${r.algorithm || '-'}</td>
        <td class="py-3 px-4 font-mono font-bold ${scoreColor} text-xs">${r.priority_score}</td>
        <td class="py-3 px-4 font-semibold ${waveColor} text-xs">Wave ${r.migration_wave}</td>
        <td class="py-3 px-4 text-gray-300 text-xs truncate max-w-xs">${r.recommended_action || '-'}</td>
        <td class="py-3 px-4 text-center">
          <button onclick='openModal(${safeR})' class="px-2 py-1 rounded bg-gray-800 hover:bg-gray-700 text-gray-300 text-xs transition">Inspect</button>
        </td>
      </tr>`;
  }).join('');
}

/* ── Scanner ────────────────────────────────────────────────────────────── */
async function triggerRepoScan() {
  const customPath = document.getElementById('scanPathInput')?.value.trim() || '';
  showAlert('Scanning repository for cryptographic primitives...', 'info');
  try {
    const data = await API.scanRepo(customPath);
    const tbody = document.getElementById('scannerTableBody');
    if (!tbody) return;
    if (!data.records?.length) {
      tbody.innerHTML = '<tr><td colspan="6" class="py-8 text-center text-gray-500">No assets found.</td></tr>';
      showAlert('Scan complete — no assets discovered.', 'info');
      return;
    }
    tbody.innerHTML = data.records.map(r => {
      const labelKey = (r.predicted_label || 'unknown').toLowerCase().replace(/_/g, '-');
      const waveColor = String(r.migration_wave) === '1' ? 'text-red-400' : String(r.migration_wave) === '2' ? 'text-yellow-400' : 'text-blue-400';
      return `
        <tr class="hover:bg-gray-800/40 transition border-b border-gray-800/60">
          <td class="py-2.5 px-4 font-mono font-bold text-blue-400 text-xs">${r.asset_id}</td>
          <td class="py-2.5 px-4 text-gray-400 text-xs">${r.location || '-'}</td>
          <td class="py-2.5 px-4 text-gray-200 text-xs">${r.algorithm || '-'}</td>
          <td class="py-2.5 px-4 text-gray-400 text-xs">${r.primitive || '-'}</td>
          <td class="py-2.5 px-4"><span class="badge badge-${labelKey}">${r.predicted_label}</span></td>
          <td class="py-2.5 px-4 font-semibold ${waveColor} text-xs">Wave ${r.migration_wave}</td>
        </tr>`;
    }).join('');
    showAlert(`Discovered ${data.discovered_count} assets in repository.`, 'success');
  } catch (err) {
    showAlert(`Scanner error: ${err.message}`, 'error');
  }
}

/* ── Benchmark ──────────────────────────────────────────────────────────── */
async function loadBenchmark() {
  showAlert('Loading benchmark comparison...', 'info');
  try {
    const data = await API.getBenchmark();
    const tbody = document.getElementById('benchmarkTableBody');
    if (!tbody) return;
    const rows = data.comparison || data.metrics || [];
    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="4" class="py-8 text-center text-gray-500">No benchmark data available.</td></tr>';
      return;
    }
    tbody.innerHTML = rows.map(row => {
      const ours  = typeof row.our_model  === 'number' ? (row.our_model  * (row.metric?.toLowerCase().includes('score') || row.metric?.toLowerCase().includes('f1') || row.metric?.toLowerCase().includes('acc') || row.metric?.toLowerCase().includes('prec') || row.metric?.toLowerCase().includes('rec') ? 100 : 1)).toFixed(2) : row.our_model;
      const base  = typeof row.baseline   === 'number' ? (row.baseline   * (row.metric?.toLowerCase().includes('score') || row.metric?.toLowerCase().includes('f1') || row.metric?.toLowerCase().includes('acc') || row.metric?.toLowerCase().includes('prec') || row.metric?.toLowerCase().includes('rec') ? 100 : 1)).toFixed(2) : row.baseline;
      const delta = row.delta !== undefined ? (row.delta >= 0 ? `<span class="text-emerald-400">+${(row.delta*100).toFixed(2)}%</span>` : `<span class="text-red-400">${(row.delta*100).toFixed(2)}%</span>`) : '-';
      return `
        <tr class="hover:bg-gray-800/40 transition border-b border-gray-800/60">
          <td class="py-3 px-5 text-gray-200 font-medium text-sm">${row.metric || row.Metric || '-'}</td>
          <td class="py-3 px-5 text-center font-mono font-bold text-emerald-400">${ours}</td>
          <td class="py-3 px-5 text-center font-mono text-gray-400">${base}</td>
          <td class="py-3 px-5 text-center">${delta}</td>
        </tr>`;
    }).join('');
    showAlert('Benchmark data loaded.', 'success');
  } catch (err) {
    showAlert(`Benchmark error: ${err.message}`, 'error');
  }
}

/* ── Modal ──────────────────────────────────────────────────────────────── */
function openModal(r) {
  document.getElementById('modalAssetId').textContent = r.asset_id;
  const badge = document.getElementById('modalLabelBadge');
  const labelKey = (r.predicted_label || 'unknown').toLowerCase().replace(/_/g, '-');
  badge.textContent = r.predicted_label;
  badge.className = `badge badge-${labelKey}`;

  document.getElementById('modalAlg').textContent        = `${r.algorithm || 'Unknown'} (${r.primitive || 'unspecified'})`;
  document.getElementById('modalScoreWave').textContent  = `Score: ${r.priority_score} | Wave ${r.migration_wave} (Rank #${r.priority_rank || 'N/A'})`;
  document.getElementById('modalAction').textContent     = r.recommended_action || 'No action specified';
  document.getElementById('modalRationale').textContent  = r.rationale           || 'No rationale available';

  const modal = document.getElementById('detailModal');
  modal.classList.remove('hidden');
  modal.querySelector('div').classList.add('modal-enter');
}

function closeModal() {
  document.getElementById('detailModal').classList.add('hidden');
}

/* ── Tab Switcher ───────────────────────────────────────────────────────── */
function switchTab(tabId) {
  document.querySelectorAll('.tab-panel').forEach(el => el.classList.add('hidden'));
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('active-tab');
    btn.classList.add('text-gray-400');
    btn.classList.remove('text-blue-400');
  });

  document.getElementById('tab-'    + tabId)?.classList.remove('hidden');
  const btn = document.getElementById('tabBtn-' + tabId);
  if (btn) {
    btn.classList.add('active-tab', 'text-blue-400');
    btn.classList.remove('text-gray-400');
  }

  if (tabId === 'dashboard') {
    ChartService.renderCategoryDonut('categoryChart', currentSummary.label_distribution);
    ChartService.renderWaveBar('waveChart', currentSummary.wave_distribution);
  }
}

/* ── Export ─────────────────────────────────────────────────────────────── */
function exportPredictions() {
  window.location.href = API.exportPredictionsUrl();
}

/* ── Alert ──────────────────────────────────────────────────────────────── */
function showAlert(msg, type = 'info') {
  const bar   = document.getElementById('alertBar');
  const inner = document.getElementById('alertInner');
  const msgEl = document.getElementById('alertMsg');
  if (!bar || !inner || !msgEl) return;

  inner.className = 'rounded-lg px-4 py-3 text-sm flex items-center justify-between ';
  if (type === 'success') inner.className += 'bg-emerald-950/70 border border-emerald-800 text-emerald-300';
  else if (type === 'error') inner.className += 'bg-red-950/70 border border-red-800 text-red-300';
  else inner.className += 'bg-blue-950/70 border border-blue-800 text-blue-300';

  msgEl.textContent = msg;
  bar.classList.remove('hidden');
  if (type === 'success') setTimeout(hideAlert, 4000);
}

function hideAlert() {
  document.getElementById('alertBar')?.classList.add('hidden');
}
